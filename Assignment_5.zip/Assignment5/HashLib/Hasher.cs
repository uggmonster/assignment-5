using System.Security.Cryptography;
using System.Text;

namespace HashLib
{
    // DLL component: hashes locally so a password is never sent to a remote service in clear text.
    public static class Hasher
    {
        // Input: any string. Output: 64-character hexadecimal SHA-256 hash.
        public static string Sha256Hash(string input)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(input ?? ""));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
    }
}
