using System;
using System.Configuration;
using System.ServiceModel;
using HashLib;

namespace Assignment5WebApp
{
    // Client copy of the WordFilter service contract, used to call the service.
    [ServiceContract(Name = "IWordFilter", Namespace = "http://cse445.asu.edu/WordFilter")]
    public interface IWordFilterClient
    {
        [OperationContract]
        string WordFilter(string str);
    }

    public partial class Default : System.Web.UI.Page
    {
        // Show the visitor count kept by Global.asax.
        protected void Page_Load(object sender, EventArgs e)
        {
            lblVisitors.Text = Application["VisitorCount"].ToString();
        }

        protected void btnMember_Click(object sender, EventArgs e)
        {
            Response.Redirect("Member.aspx");
        }

        protected void btnStaff_Click(object sender, EventArgs e)
        {
            Response.Redirect("Staff.aspx");
        }

        // TryIt 1: hash the input with the HashLib DLL.
        protected void btnHash_Click(object sender, EventArgs e)
        {
            lblHash.Text = Hasher.Sha256Hash(txtHashInput.Text);
        }

        // TryIt 3: call the WordFilter service and show its result.
        protected void btnFilter_Click(object sender, EventArgs e)
        {
            // Address from Web.config; if empty (WebStrar), use the relative address of Page1.
            string url = ConfigurationManager.AppSettings["WordFilterServiceUrl"];
            if (string.IsNullOrWhiteSpace(url))
                url = new Uri(Request.Url, "../Page1/WordFilter.svc").AbsoluteUri;

            var factory = new ChannelFactory<IWordFilterClient>(new BasicHttpBinding(), new EndpointAddress(url));
            try
            {
                lblFilterResult.Text = Server.HtmlEncode(factory.CreateChannel().WordFilter(txtFilterInput.Text));
                factory.Close();
            }
            catch (Exception ex)
            {
                factory.Abort();
                lblFilterResult.Text = "Service call failed: " + Server.HtmlEncode(ex.Message);
            }
        }
    }
}
