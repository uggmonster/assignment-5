<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Assignment5WebApp.Default" ValidateRequest="false" %>
<!DOCTYPE html>
<html>
<head runat="server">
    <title>CSE 445 Assignment 5</title>
</head>
<body>
    <form id="form1" runat="server">
        <h1>CSE 445 Assignment 5 - Default Page</h1>
        <p>Current page: <a href="<%: Request.Url.AbsoluteUri %>"><%: Request.Url.AbsoluteUri %></a></p>

        <p>This application lists its components and services in the Service Directory below, with a
            TryIt section for each. Sign-up (Member page) and the Staff page are added in Assignment 6;
            testing needs no account. Test cases are given in each TryIt section.</p>

        <asp:Button ID="btnMember" runat="server" Text="Member Page" OnClick="btnMember_Click" />
        <asp:Button ID="btnStaff" runat="server" Text="Staff Page" OnClick="btnStaff_Click" />

        <h2>Service Directory</h2>
        <table border="1" cellpadding="5">
            <tr>
                <th>Provider</th><th>Type</th><th>Operation</th><th>Parameters</th>
                <th>Returns</th><th>Description</th><th>TryIt</th>
            </tr>
            <tr>
                <td>Josh Quist</td><td>DLL (HashLib.dll)</td><td>Sha256Hash</td><td>string input</td>
                <td>string</td><td>Computes the SHA-256 hash of a string locally.</td><td><a href="#tryHash">TryIt 1</a></td>
            </tr>
            <tr>
                <td>Josh Quist</td><td>Global.asax</td><td>Application_Start, Session_Start</td><td>none</td>
                <td>int (Application state)</td><td>Counts visitors (sessions).</td><td><a href="#tryGlobal">TryIt 2</a></td>
            </tr>
            <tr>
                <td>Josh Quist</td><td>WSDL service (WordFilter.svc)</td><td>WordFilter</td><td>string str</td>
                <td>string</td><td>Removes tags and stop words from text.</td><td><a href="#tryService">TryIt 3</a></td>
            </tr>
        </table>

        <h3 id="tryHash">TryIt 1 - Hash (DLL)</h3>
        <p>Test: input <b>Cse445!</b> gives <b>d85b22f0890f5e82d76967037156f2a0bf779bcd44123bd5a2fa7ab299a289d6</b></p>
        <asp:TextBox ID="txtHashInput" runat="server" Text="Cse445!"></asp:TextBox>
        <asp:Button ID="btnHash" runat="server" Text="Hash" OnClick="btnHash_Click" />
        <asp:Label ID="lblHash" runat="server"></asp:Label>

        <h3 id="tryGlobal">TryIt 2 - Visitor count (Global.asax)</h3>
        <p>Test: open this page in a private window; the count increases by 1.</p>
        Visitors: <asp:Label ID="lblVisitors" runat="server"></asp:Label>

        <h3 id="tryService">TryIt 3 - WordFilter service</h3>
        <p>Test: input <b>&lt;p class="x"&gt;The cat is on the mat&lt;/p&gt;</b> gives <b>cat mat</b></p>
        <asp:TextBox ID="txtFilterInput" runat="server" Width="350px"
            Text="&lt;p class=&quot;x&quot;&gt;The cat is on the mat&lt;/p&gt;"></asp:TextBox>
        <asp:Button ID="btnFilter" runat="server" Text="Filter" OnClick="btnFilter_Click" />
        <asp:Label ID="lblFilterResult" runat="server"></asp:Label>
    </form>
</body>
</html>
