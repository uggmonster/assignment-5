<%@ Page Language="C#" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server"><title>Staff Page</title></head>
<body>
    <h2>Staff Page</h2>
    <p>Placeholder. The Staff page (Staff.xml credentials, Forms Security) is built in Assignment 6.</p>
    <p><a href="Default.aspx">Back to Default page</a></p>
</body>
</html>
