namespace Assignment5WebApp
{
    public partial class Default
    {
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        protected global::System.Web.UI.WebControls.Button btnMember;
        protected global::System.Web.UI.WebControls.Button btnStaff;
        protected global::System.Web.UI.WebControls.TextBox txtHashInput;
        protected global::System.Web.UI.WebControls.Button btnHash;
        protected global::System.Web.UI.WebControls.Label lblHash;
        protected global::System.Web.UI.WebControls.Label lblVisitors;
        protected global::System.Web.UI.WebControls.TextBox txtFilterInput;
        protected global::System.Web.UI.WebControls.Button btnFilter;
        protected global::System.Web.UI.WebControls.Label lblFilterResult;
    }
}
