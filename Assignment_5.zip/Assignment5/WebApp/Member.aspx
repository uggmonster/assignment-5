<%@ Page Language="C#" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server"><title>Member Page</title></head>
<body>
    <h2>Member Page</h2>
    <p>Placeholder. The Member page (sign-up with captcha, Forms Security login) is built in Assignment 6.</p>
    <p><a href="Default.aspx">Back to Default page</a></p>
</body>
</html>
