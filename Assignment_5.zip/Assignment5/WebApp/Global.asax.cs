using System;
using System.Web;

namespace Assignment5WebApp
{
    // Global.asax component: counts visitors in Application state (shared by all users).
    public class Global : HttpApplication
    {
        // Runs once when the application starts.
        protected void Application_Start(object sender, EventArgs e)
        {
            Application["VisitorCount"] = 0;
        }

        // Runs when a new user session starts; Lock prevents two sessions updating at the same time.
        protected void Session_Start(object sender, EventArgs e)
        {
            Application.Lock();
            Application["VisitorCount"] = (int)Application["VisitorCount"] + 1;
            Application.UnLock();
        }
    }
}
