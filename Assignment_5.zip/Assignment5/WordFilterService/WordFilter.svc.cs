using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace WordFilterService
{
    // WSDL service. Provider: Josh Quist.
    public class WordFilterSvc : IWordFilter
    {
        // Function words that are not counted as content words.
        private static readonly HashSet<string> StopWords = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "a", "an", "the", "and", "or", "but", "in", "on", "at", "of", "to", "for", "from", "by", "with",
            "is", "are", "am", "was", "were", "be", "been", "do", "does", "did", "have", "has", "had",
            "it", "this", "that", "i", "you", "he", "she", "we", "they", "not", "no", "if", "then"
        };

        public string WordFilter(string str)
        {
            if (string.IsNullOrWhiteSpace(str)) return "";

            // Remove XML/HTML tags, which also removes element and attribute names.
            string text = Regex.Replace(str, "<[^>]*>", " ");

            // Split into words and keep only those that are not stop words.
            var words = Regex.Matches(text, "[A-Za-z0-9']+").Cast<Match>()
                             .Select(m => m.Value.Trim('\''))
                             .Where(w => w.Length > 0 && !StopWords.Contains(w));
            return string.Join(" ", words);
        }
    }
}
