using System.ServiceModel;

namespace WordFilterService
{
    [ServiceContract(Namespace = "http://cse445.asu.edu/WordFilter")]
    public interface IWordFilter
    {
        // Input: text (plain, HTML or XML). Output: the text without tags and stop words.
        [OperationContract]
        string WordFilter(string str);
    }
}
